Sample configuration files for:
```
SystemD: mnpostreed.service
Upstart: mnpostreed.conf
OpenRC:  mnpostreed.openrc
         mnpostreed.openrcconf
CentOS:  mnpostreed.init
macOS:    org.mnpostree.mnpostreed.plist
```
have been made available to assist packagers in creating node packages here.

See doc/init.md for more information.
